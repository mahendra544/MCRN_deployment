# MCRN Authentication Module — Redesigned

## What changed
- Spring Boot backend removed and replaced with Node.js + Express.
- Direct SMTP delivery through Nodemailer.
- Email OTP registration verification and password reset.
- OTPs are bcrypt-hashed, expire after 10 minutes, are one-time use, have a 5-attempt limit, and have a resend cooldown.
- Password visibility eye toggle added everywhere passwords are entered.
- New cinematic/glass authentication UI with responsive mobile behavior.
- JWT session restoration, CORS allowlist, Helmet headers, login rate limiting, bcrypt passwords, and temporary lockout after repeated failures.

## Run
### Backend
```bash
cd backend
cp .env.example .env
# configure MySQL, JWT_SECRET and SMTP
npm install
npm run dev
```

### Frontend
```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

The frontend defaults to `http://localhost:8080/api`. Set `VITE_API_URL` if needed.
