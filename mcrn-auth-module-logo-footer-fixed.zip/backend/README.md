# MCRN Authentication API

Node.js + Express + MySQL + Nodemailer. Spring Boot is no longer required.

## Start
```bash
cp .env.example .env
# fill database, JWT and SMTP values
npm install
npm run dev
```

The API creates its tables on startup. **SMTP is required outside development**; OTPs are never returned in API responses or browser-visible logs.

Security included: bcrypt password hashes, hashed OTPs, 10-minute expiry, one-time OTP use, 5 verification attempts, resend cooldown, login rate limiting, account lockout, Helmet, CORS allowlist and JWT authentication.
