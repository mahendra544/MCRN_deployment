
import nodemailer from "nodemailer";

let transporter;

function mailConfig() {
  const host = process.env.MAIL_HOST;
  // Accept both MAIL_USERNAME (documented) and MAIL_USER (legacy).
  const user = process.env.MAIL_USERNAME || process.env.MAIL_USER;
  const pass = process.env.MAIL_PASSWORD;
  if (!host || !user || !pass) return null;
  return {
    host,
    port: Number(process.env.MAIL_PORT || 587),
    secure: String(process.env.MAIL_SECURE) === "true",
    auth: { user, pass },
    requireTLS: String(process.env.MAIL_REQUIRE_TLS || "true") === "true"
  };
}

export async function verifyMailer() {
  const config = mailConfig();
  if (!config) {
    if (process.env.NODE_ENV === "production") throw new Error("SMTP is not configured");
    console.warn("SMTP is not configured. Mail delivery is disabled in development.");
    return;
  }
  transporter = nodemailer.createTransport(config);
  await transporter.verify();
  console.log("SMTP connection verified.");
}

function html(title, otp, copy) {
  return `<!doctype html><html><body style="margin:0;background:#080b12;color:#eef2ff;font-family:Arial,sans-serif">
  <div style="max-width:560px;margin:40px auto;padding:32px;background:#111827;border:1px solid #283449;border-radius:24px">
  <div style="color:#e85d4f;font-weight:700;letter-spacing:2px;font-size:12px">MCRN • SECURE ACCESS</div>
  <h1 style="font-size:28px">${title}</h1><p style="color:#aab4c6">${copy}</p>
  <div style="margin:28px 0;padding:20px;text-align:center;font-size:32px;font-weight:800;letter-spacing:10px;background:#0b1220;border-radius:16px">${otp}</div>
  <p style="color:#aab4c6;font-size:13px">This code expires in 10 minutes and can be used once. Never share it.</p>
  </div></body></html>`;
}

export async function sendOtp(to, otp, purpose) {
  if (!transporter) {
    if (process.env.NODE_ENV === "production") throw new Error("Email service unavailable");
    console.info(`Development email suppressed for ${to}; configure SMTP to deliver OTPs.`);
    return;
  }
  const reset = purpose === "PASSWORD_RESET";
  await transporter.sendMail({
    from: process.env.MAIL_FROM || process.env.MAIL_USERNAME || process.env.MAIL_USER,
    to,
    subject: reset ? "MCRN password reset code" : "Verify your MCRN account",
    text: `Your MCRN ${reset ? "password reset" : "verification"} code is ${otp}. It expires in 10 minutes.`,
    html: html(reset ? "Reset your password" : "Verify your email", otp,
      reset ? "Use this one-time code to continue resetting your password." : "Use this one-time code to activate your MCRN account.")
  });
}
