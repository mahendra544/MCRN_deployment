
import mysql from "mysql2/promise";

export const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "mcrn_auth",
  waitForConnections: true,
  connectionLimit: 10,
  timezone: "Z"
});

export async function initDb() {
  const admin = await mysql.createConnection({
    host: process.env.DB_HOST || "localhost",
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASSWORD || ""
  });
  const db = process.env.DB_NAME || "mcrn_auth";
  if (!/^[A-Za-z0-9_]+$/.test(db)) throw new Error("Invalid DB_NAME");
  await admin.query(`CREATE DATABASE IF NOT EXISTS \`${db}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
  await admin.end();

  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id BIGINT PRIMARY KEY AUTO_INCREMENT,
      username VARCHAR(50) NOT NULL UNIQUE,
      name VARCHAR(100) NOT NULL,
      email VARCHAR(254) NOT NULL UNIQUE,
      password_hash VARCHAR(255) NOT NULL,
      role ENUM('USER','POLICE','ADMIN') NOT NULL DEFAULT 'USER',
      verified BOOLEAN NOT NULL DEFAULT FALSE,
      active BOOLEAN NOT NULL DEFAULT TRUE,
      failed_login_attempts INT NOT NULL DEFAULT 0,
      locked_until DATETIME NULL,
      phone VARCHAR(20) NULL,
      profile_photo_url VARCHAR(500) NULL,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB`);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS police_profiles (
      user_id BIGINT PRIMARY KEY,
      official_id VARCHAR(80) NOT NULL UNIQUE,
      CONSTRAINT fk_police_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB`);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS otp_tokens (
      id BIGINT PRIMARY KEY AUTO_INCREMENT,
      email VARCHAR(254) NOT NULL,
      purpose ENUM('REGISTRATION_VERIFICATION','PASSWORD_RESET') NOT NULL,
      code_hash VARCHAR(255) NOT NULL,
      expires_at DATETIME NOT NULL,
      attempts INT NOT NULL DEFAULT 0,
      consumed BOOLEAN NOT NULL DEFAULT FALSE,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_otp_lookup(email, purpose, consumed, created_at)
    ) ENGINE=InnoDB`);
}
