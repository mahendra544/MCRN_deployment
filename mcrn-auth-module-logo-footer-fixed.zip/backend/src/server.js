
import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { randomInt } from "node:crypto";
import { z } from "zod";
import { pool, initDb } from "./db.js";
import { sendOtp, verifyMailer } from "./mail.js";

const app = express();
const PORT = Number(process.env.PORT || 8080);
const jwtSecret = process.env.JWT_SECRET;
if (!jwtSecret || jwtSecret.length < 32) throw new Error("JWT_SECRET must be at least 32 characters");

const origins = (process.env.CORS_ORIGINS || "http://localhost:5173,http://127.0.0.1:5173").split(",").map(x => x.trim()).filter(Boolean);
app.use(helmet());
app.use(cors({ origin(origin, cb) { if (!origin || origins.includes(origin)) return cb(null, true); cb(new Error("Origin not allowed")); }, methods:["GET","POST","PUT"], allowedHeaders:["Content-Type","Authorization"] }));
app.use(express.json({ limit: "100kb" }));

const authLimiter = rateLimit({ windowMs: 15*60*1000, max: 100, standardHeaders:true, legacyHeaders:false, message:{message:"Too many requests. Please try again later."} });
const loginLimiter = rateLimit({ windowMs: 15*60*1000, max: 20, standardHeaders:true, legacyHeaders:false, message:{message:"Too many login attempts. Please try again later."} });
app.use("/api/auth", authLimiter);

const password = z.string().min(8).max(72).regex(/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d])/,"Password must include upper, lower, number and special character");
const email = z.string().email().max(254).transform(v=>v.trim().toLowerCase());
const username = z.string().trim().min(3).max(50);
const otp = z.string().regex(/^\d{6}$/);
const parse = schema => (req,res,next) => {
  const out=schema.safeParse(req.body);
  if(!out.success) return res.status(400).json({message:out.error.issues[0].message});
  req.body=out.data; next();
};
const schemas={
 user:z.object({username,email,password}),
 police:z.object({name:z.string().trim().min(2).max(100),username,email,password,officialId:z.string().trim().min(3).max(80)}),
 login:z.object({username,password:z.string().min(1).max(72)}),
 verify:z.object({email,otp}),
 forgot:z.object({email}),
 reset:z.object({email,otp,newPassword:password}),
 resend:z.object({email,purpose:z.enum(["REGISTRATION_VERIFICATION","PASSWORD_RESET"]).default("REGISTRATION_VERIFICATION")}),
 profile:z.object({name:z.string().trim().min(2).max(100),phone:z.string().trim().max(20).optional().or(z.literal("")),profilePhotoUrl:z.string().trim().max(500).optional().or(z.literal(""))}),
 changePassword:z.object({currentPassword:z.string().min(1).max(72),newPassword:password})
};

function sign(u){return jwt.sign({sub:String(u.id),username:u.username,role:u.role},jwtSecret,{expiresIn:process.env.JWT_EXPIRES_IN||"1h"});}
function auth(req,res,next){try{req.user=jwt.verify((req.headers.authorization||"").replace(/^Bearer\s+/i,""),jwtSecret);next();}catch{return res.status(401).json({message:"Unauthorized"});}}
function normalizeEmail(v){return v.trim().toLowerCase();}
function publicUser(u){return {id:u.id,username:u.username,name:u.name,email:u.email,role:u.role};}
async function issueOtp(emailAddr,purpose,{enforceCooldown=true}={}) {
  const conn=await pool.getConnection();
  let code;
  try{
    await conn.beginTransaction();
    const [recent]=await conn.query(`SELECT created_at FROM otp_tokens WHERE email=? AND purpose=? AND consumed=0 ORDER BY created_at DESC LIMIT 1 FOR UPDATE`,[emailAddr,purpose]);
    if(enforceCooldown && recent[0] && Date.now()-new Date(recent[0].created_at).getTime()<60*1000){
      const err=new Error("Please wait before requesting another code."); err.status=429; throw err;
    }
    await conn.query(`UPDATE otp_tokens SET consumed=1 WHERE email=? AND purpose=? AND consumed=0`,[emailAddr,purpose]);
    code=String(randomInt(100000,1000000));
    const hash=await bcrypt.hash(code,12);
    await conn.query(`INSERT INTO otp_tokens(email,purpose,code_hash,expires_at,attempts,consumed) VALUES(?,?,?,?,0,0)`,[emailAddr,purpose,hash,new Date(Date.now()+10*60*1000)]);
    await conn.commit();
  }catch(e){await conn.rollback();throw e;}finally{conn.release();}
  await sendOtp(emailAddr,code,purpose);
}

app.post("/api/auth/register/user",parse(schemas.user),async(req,res,next)=>{
 try{
  const {username,email,password}=req.body; const hash=await bcrypt.hash(password,12);
  const conn=await pool.getConnection(); let id;
  try{await conn.beginTransaction();const [exists]=await conn.query("SELECT id FROM users WHERE username=? OR email=? LIMIT 1",[username,email]);if(exists.length) return res.status(409).json({message:"Username or email is already registered"});const [r]=await conn.query("INSERT INTO users(username,name,email,password_hash,role) VALUES(?,?,?,?, 'USER')",[username,username,email,hash]);id=r.insertId;await conn.commit();}catch(e){await conn.rollback();throw e;}finally{conn.release();}
  await issueOtp(email,"REGISTRATION_VERIFICATION",{enforceCooldown:false}); res.status(201).json({message:"Registration successful. Check your email for the verification code.",id});
 }catch(e){next(e);}
});
app.post("/api/auth/register/police",parse(schemas.police),async(req,res,next)=>{
 try{
  const {name,username,email,password,officialId}=req.body; const hash=await bcrypt.hash(password,12); const conn=await pool.getConnection(); let id;
  try{await conn.beginTransaction();const [exists]=await conn.query("SELECT id FROM users WHERE username=? OR email=? LIMIT 1",[username,email]);if(exists.length)return res.status(409).json({message:"Username or email is already registered"});const [oid]=await conn.query("SELECT user_id FROM police_profiles WHERE official_id=? LIMIT 1",[officialId]);if(oid.length)return res.status(409).json({message:"Official ID is already registered"});const [r]=await conn.query("INSERT INTO users(username,name,email,password_hash,role) VALUES(?,?,?,?, 'POLICE')",[username,name,email,hash]);id=r.insertId;await conn.query("INSERT INTO police_profiles(user_id,official_id) VALUES(?,?)",[id,officialId]);await conn.commit();}catch(e){await conn.rollback();throw e;}finally{conn.release();}
  await issueOtp(email,"REGISTRATION_VERIFICATION",{enforceCooldown:false});res.status(201).json({message:"Police registration successful. Check your email for the verification code.",id});
 }catch(e){next(e);}
});
app.post("/api/auth/login",loginLimiter,parse(schemas.login),async(req,res,next)=>{
 try{
  const [rows]=await pool.query("SELECT * FROM users WHERE username=? LIMIT 1",[req.body.username]);const u=rows[0];
  if(!u||!u.active) return res.status(401).json({message:"Invalid username or password"});
  if(u.locked_until && new Date(u.locked_until)>new Date()) return res.status(423).json({message:"Account temporarily locked. Try again later."});
  if(!u.verified) return res.status(403).json({message:"EMAIL_NOT_VERIFIED",email:u.email});
  if(!(await bcrypt.compare(req.body.password,u.password_hash))){const attempts=u.failed_login_attempts+1;if(attempts>=5)await pool.query("UPDATE users SET failed_login_attempts=0,locked_until=DATE_ADD(UTC_TIMESTAMP(),INTERVAL 15 MINUTE) WHERE id=?",[u.id]);else await pool.query("UPDATE users SET failed_login_attempts=? WHERE id=?",[attempts,u.id]);return res.status(401).json({message:"Invalid username or password"});}
  await pool.query("UPDATE users SET failed_login_attempts=0,locked_until=NULL WHERE id=?",[u.id]);res.json({...publicUser(u),token:sign(u)});
 }catch(e){next(e);}
});
app.post("/api/auth/verify-email",parse(schemas.verify),async(req,res,next)=>{
 try{
  const conn=await pool.getConnection();try{await conn.beginTransaction();const [[u]]=await conn.query("SELECT id FROM users WHERE email=? FOR UPDATE",[req.body.email]);if(!u)return res.status(400).json({message:"Invalid verification request"});const [[t]]=await conn.query("SELECT * FROM otp_tokens WHERE email=? AND purpose='REGISTRATION_VERIFICATION' AND consumed=0 ORDER BY created_at DESC LIMIT 1 FOR UPDATE",[req.body.email]);if(!t||new Date(t.expires_at)<new Date())throw Object.assign(new Error("OTP expired or not found"),{status:400});if(t.attempts>=5)throw Object.assign(new Error("Too many OTP attempts. Request a new OTP."),{status:400});await conn.query("UPDATE otp_tokens SET attempts=attempts+1 WHERE id=?",[t.id]);if(!(await bcrypt.compare(req.body.otp,t.code_hash)))throw Object.assign(new Error("Invalid OTP"),{status:400});await conn.query("UPDATE otp_tokens SET consumed=1 WHERE id=?",[t.id]);await conn.query("UPDATE users SET verified=1 WHERE id=?",[u.id]);await conn.commit();res.json({message:"Email verified successfully. You can now log in."});}catch(e){await conn.rollback();throw e;}finally{conn.release();}
 }catch(e){next(e);}
});
app.post("/api/auth/resend-otp",parse(schemas.resend),async(req,res,next)=>{
 try{const [[u]]=await pool.query("SELECT id,verified FROM users WHERE email=?",[req.body.email]);if(!u)return res.json({message:"If the account is eligible, a new code has been sent."});if(req.body.purpose==="REGISTRATION_VERIFICATION"&&u.verified)return res.status(400).json({message:"This email is already verified"});await issueOtp(req.body.email,req.body.purpose);res.json({message:"A new verification code has been sent."});}catch(e){next(e);}
});
app.post("/api/auth/forgot-password",parse(schemas.forgot),async(req,res,next)=>{try{const [[u]]=await pool.query("SELECT email FROM users WHERE email=?",[req.body.email]);if(u)await issueOtp(u.email,"PASSWORD_RESET");res.json({message:"If an account exists for that email, a password reset code has been sent."});}catch(e){next(e);}});
app.post("/api/auth/reset-password",parse(schemas.reset),async(req,res,next)=>{
 try{const conn=await pool.getConnection();try{await conn.beginTransaction();const [[u]]=await conn.query("SELECT id FROM users WHERE email=? FOR UPDATE",[req.body.email]);const [[t]]=await conn.query("SELECT * FROM otp_tokens WHERE email=? AND purpose='PASSWORD_RESET' AND consumed=0 ORDER BY created_at DESC LIMIT 1 FOR UPDATE",[req.body.email]);if(!u||!t||new Date(t.expires_at)<new Date())throw Object.assign(new Error("OTP expired or not found"),{status:400});if(t.attempts>=5)throw Object.assign(new Error("Too many OTP attempts. Request a new OTP."),{status:400});await conn.query("UPDATE otp_tokens SET attempts=attempts+1 WHERE id=?",[t.id]);if(!(await bcrypt.compare(req.body.otp,t.code_hash)))throw Object.assign(new Error("Invalid OTP"),{status:400});const hash=await bcrypt.hash(req.body.newPassword,12);await conn.query("UPDATE otp_tokens SET consumed=1 WHERE id=?",[t.id]);await conn.query("UPDATE users SET password_hash=?,failed_login_attempts=0,locked_until=NULL WHERE id=?",[hash,u.id]);await conn.commit();res.json({message:"Password reset successfully."});}catch(e){await conn.rollback();throw e;}finally{conn.release();}}catch(e){next(e);}
});
app.get("/api/user/profile",auth,async(req,res,next)=>{try{const [[u]]=await pool.query("SELECT id,username,name,email,phone,profile_photo_url,role,verified FROM users WHERE id=?",[req.user.sub]);if(!u)return res.status(401).json({message:"Unauthorized"});res.json({id:u.id,username:u.username,name:u.name,email:u.email,phone:u.phone,profilePhotoUrl:u.profile_photo_url,role:u.role,verified:Boolean(u.verified)});}catch(e){next(e);}});
app.put("/api/user/profile",auth,parse(schemas.profile),async(req,res,next)=>{try{await pool.query("UPDATE users SET name=?,phone=?,profile_photo_url=? WHERE id=?",[req.body.name,req.body.phone||null,req.body.profilePhotoUrl||null,req.user.sub]);res.json({message:"Profile updated"});}catch(e){next(e);}});
app.put("/api/user/change-password",auth,parse(schemas.changePassword),async(req,res,next)=>{try{const [[u]]=await pool.query("SELECT password_hash FROM users WHERE id=?",[req.user.sub]);if(!u||!(await bcrypt.compare(req.body.currentPassword,u.password_hash)))return res.status(400).json({message:"Current password is incorrect"});await pool.query("UPDATE users SET password_hash=? WHERE id=?",[await bcrypt.hash(req.body.newPassword,12),req.user.sub]);res.json({message:"Password changed successfully."});}catch(e){next(e);}});
app.use((err,req,res,next)=>{console.error(err);res.status(err.status||500).json({message:err.status&&err.status<500?err.message:"Something went wrong. Please try again."});});
await initDb(); await verifyMailer(); app.listen(PORT,()=>console.log(`MCRN API listening on :${PORT}`));
