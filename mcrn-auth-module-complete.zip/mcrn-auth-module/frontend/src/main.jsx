import React,{useEffect,useState} from 'react';
import {createRoot} from 'react-dom/client';
import {ShieldCheck, UserRound, BadgeCheck, LockKeyhole, Mail, ArrowLeft, LogOut} from 'lucide-react';
import './index.css';

const API='http://localhost:8080/api';
const req=async(path,body,token)=>{
  const r=await fetch(API+path,{method:'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:`Bearer ${token}`}:{})},body:JSON.stringify(body)});
  const data=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(data.message||'Request failed');
  return data;
};
const put=async(path,body,token)=>{
 const r=await fetch(API+path,{method:'PUT',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify(body)});
 const d=await r.json().catch(()=>({})); if(!r.ok) throw new Error(d.message||'Request failed'); return d;
};
const get=async(path,token)=>{
 const r=await fetch(API+path,{headers:{Authorization:`Bearer ${token}`}});
 const d=await r.json().catch(()=>({})); if(!r.ok) throw new Error(d.message||'Request failed'); return d;
};

function Layout({children,onHome}){return <><header className="site-header"><div className="container nav">
<a className="brand" href="#" onClick={e=>{e.preventDefault();onHome()}}><span className="brand-mark">M</span><span className="brand-copy"><strong>Missing Child</strong><span>Rescue Network</span></span></a>
<div className="nav-actions"><button className="btn btn-ghost btn-sm" onClick={onHome}>Home</button></div>
</div></header>{children}</>}

function AuthCard({title,subtitle,children,onBack}){return <main className="section"><div className="container" style={{maxWidth:520}}><div className="panel" style={{padding:32}}>{onBack&&<button className="btn btn-ghost btn-sm" onClick={onBack}><ArrowLeft size={15}/> Back</button>}<div className="section-heading" style={{marginTop:20}}><span className="eyebrow">Secure Access</span><h2>{title}</h2><p className="muted">{subtitle}</p></div>{children}</div></div></main>}

function Field({label,type='text',value,onChange,placeholder}){return <div className="field"><label>{label}</label><input className="input" type={type} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder}/></div>}
function Alert({msg,error=false}){return msg?<div className="panel" style={{marginBottom:16,padding:14,color:error?'var(--danger)':'var(--success)',background:error?'#fff0f0':'#edf9f2'}}>{msg}</div>:null}

function Home({go}){return <><section className="hero"><div className="container hero-grid"><div className="hero-content"><span className="eyebrow">Missing Child Rescue Network</span><h1 className="hero-title">Secure access for a <span className="accent">safer network.</span></h1><p className="hero-description">Authentication for public users, police officers and administrators, with email verification and role-based access.</p><div className="hero-actions"><button className="btn btn-primary" onClick={()=>go('login')}>Sign in</button><button className="btn btn-secondary" onClick={()=>go('register')}>Create account</button></div></div><div className="hero-visual"><div className="hero-orb"></div><div className="hero-panel"><div className="hero-panel-top"><div className="hero-panel-icon"><ShieldCheck/></div><span className="live-pill"><span className="live-dot"></span>Protected</span></div><h3>Role-based security</h3><p>USER, POLICE and ADMIN access is enforced by the backend.</p><div className="hero-progress"><span/></div></div></div></div></section><section className="section"><div className="container"><div className="section-heading"><span className="eyebrow">Authentication</span><h2>One module, three secure roles.</h2></div><div className="module-grid"><div className="module-card"><div className="module-icon"><UserRound/></div><h3>Public User</h3><p>Username, email, password, verification and profile management.</p></div><div className="module-card"><div className="module-icon"><BadgeCheck/></div><h3>Police</h3><p>Official ID backed registration with verified email and police role.</p></div><div className="module-card"><div className="module-icon"><LockKeyhole/></div><h3>Admin</h3><p>Privileged login with system-managed administrator credentials.</p></div><div className="module-card"><div className="module-icon"><Mail/></div><h3>Email Recovery</h3><p>OTP verification and secure forgot-password recovery.</p></div></div></div></section></>}

function Register({go}){const [role,setRole]=useState('USER'),[form,setForm]=useState({}),[msg,setMsg]=useState(''),[err,setErr]=useState('');
const set=(k,v)=>setForm({...form,[k]:v});
async function submit(e){e.preventDefault();setMsg('');setErr('');try{const p=role==='USER'?'/auth/register/user':'/auth/register/police';await req(p,role==='USER'?form:{...form});setMsg('Registration successful. Check your email for the OTP.');setTimeout(()=>go('verify',form.email),700)}catch(x){setErr(x.message)}}
return <AuthCard title="Create an account" subtitle="Choose the account type that matches your role." onBack={()=>go('home')}><div style={{display:'flex',gap:8,marginBottom:20}}><button className={`btn ${role==='USER'?'btn-primary':'btn-ghost'}`} onClick={()=>setRole('USER')}>User</button><button className={`btn ${role==='POLICE'?'btn-primary':'btn-ghost'}`} onClick={()=>setRole('POLICE')}>Police</button></div><Alert msg={msg}/><Alert msg={err} error/>{role==='POLICE'&&<Field label="Full name" value={form.name||''} onChange={v=>set('name',v)} placeholder="Officer name"/>}<Field label="Username" value={form.username||''} onChange={v=>set('username',v)} placeholder="Choose a username"/><Field label="Email" type="email" value={form.email||''} onChange={v=>set('email',v)} placeholder="you@example.com"/>{role==='POLICE'&&<Field label="Official ID" value={form.officialId||''} onChange={v=>set('officialId',v)} placeholder="Official police ID"/>}<Field label="Password" type="password" value={form.password||''} onChange={v=>set('password',v)} placeholder="8+ chars, upper/lower/digit/special"/><button className="btn btn-primary btn-block" style={{marginTop:18}} onClick={submit}>Register</button></AuthCard>}

function Login({go,setSession}){const [f,setF]=useState({username:'',password:''}),[err,setErr]=useState('');
async function submit(e){e.preventDefault();setErr('');try{const d=await req('/auth/login',f);localStorage.setItem('mcrn_token',d.token);setSession(d);go('profile')}catch(x){setErr(x.message);if(x.message==='EMAIL_NOT_VERIFIED')go('verify',f.username)}}
return <AuthCard title="Sign in" subtitle="Use your username and password." onBack={()=>go('home')}><Alert msg={err} error/><Field label="Username" value={f.username} onChange={v=>setF({...f,username:v})} placeholder="Your username"/><Field label="Password" type="password" value={f.password} onChange={v=>setF({...f,password:v})} placeholder="Your password"/><button className="btn btn-primary btn-block" style={{marginTop:18}} onClick={submit}>Login</button><button className="btn btn-ghost btn-block" style={{marginTop:10}} onClick={()=>go('forgot')}>Forgot password?</button></AuthCard>}

function Verify({email,go}){const [otp,setOtp]=useState(''),[msg,setMsg]=useState(''),[err,setErr]=useState('');
async function submit(){try{setErr('');setMsg(await req('/auth/verify-email',{email,otp}))}catch(x){setErr(x.message)}}
return <AuthCard title="Verify your email" subtitle={`Enter the 6-digit OTP sent to ${email||'your email'}.`} onBack={()=>go('login')}><Alert msg={msg}/><Alert msg={err} error/><Field label="Email" type="email" value={email||''} onChange={()=>{}}/><Field label="OTP" value={otp} onChange={setOtp} placeholder="123456"/><button className="btn btn-primary btn-block" style={{marginTop:18}} onClick={submit}>Verify email</button><button className="btn btn-ghost btn-block" style={{marginTop:10}} onClick={()=>go('login')}>Back to login</button></AuthCard>}

function Forgot({go}){const [email,setEmail]=useState(''),[msg,setMsg]=useState(''),[err,setErr]=useState('');
async function submit(){try{setErr('');setMsg(await req('/auth/forgot-password',{email}));setTimeout(()=>go('reset',email),700)}catch(x){setErr(x.message)}}
return <AuthCard title="Forgot password" subtitle="We'll send a password reset OTP to your registered email." onBack={()=>go('login')}><Alert msg={msg}/><Alert msg={err} error/><Field label="Email" type="email" value={email} onChange={setEmail} placeholder="you@example.com"/><button className="btn btn-primary btn-block" style={{marginTop:18}} onClick={submit}>Send OTP</button></AuthCard>}

function Reset({email,go}){const [f,setF]=useState({email:email||'',otp:'',newPassword:''}),[msg,setMsg]=useState(''),[err,setErr]=useState('');
async function submit(){try{setErr('');setMsg(await req('/auth/reset-password',f));}catch(x){setErr(x.message)}}
return <AuthCard title="Reset password" subtitle="Verify the OTP and choose a new password." onBack={()=>go('login')}><Alert msg={msg}/><Alert msg={err} error/><Field label="Email" type="email" value={f.email} onChange={v=>setF({...f,email:v})}/><Field label="OTP" value={f.otp} onChange={v=>setF({...f,otp:v})} placeholder="123456"/><Field label="New password" type="password" value={f.newPassword} onChange={v=>setF({...f,newPassword:v})}/><button className="btn btn-primary btn-block" style={{marginTop:18}} onClick={submit}>Reset password</button></AuthCard>}

function Profile({session,clear}){const [p,setP]=useState(null),[msg,setMsg]=useState(''),[err,setErr]=useState(''),[editing,setEditing]=useState(false),[pass,setPass]=useState({currentPassword:'',newPassword:''});
useEffect(()=>{get('/user/profile',localStorage.getItem('mcrn_token')).then(setP).catch(x=>setErr(x.message))},[]);
if(!p)return <AuthCard title="Profile" subtitle="Loading your secure profile..."/>;
async function save(){try{setMsg(await put('/user/profile',{name:p.name,phone:p.phone||'',profilePhotoUrl:p.profilePhotoUrl||''},localStorage.getItem('mcrn_token')));setEditing(false)}catch(x){setErr(x.message)}}
async function change(){try{setMsg(await put('/user/change-password',pass,localStorage.getItem('mcrn_token')))}catch(x){setErr(x.message)}}
return <main className="section"><div className="container" style={{maxWidth:760}}><div className="panel"><div className="panel-header"><div><span className="eyebrow">Account</span><h2>My Profile</h2></div><button className="btn btn-ghost" onClick={()=>{localStorage.removeItem('mcrn_token');clear()}}><LogOut size={16}/> Logout</button></div><Alert msg={msg}/><Alert msg={err} error/><div className="info-grid" style={{gridTemplateColumns:'1fr 1fr'}}><div className="info-card"><h3>Identity</h3><p><b>Username:</b> {p.username}</p><p><b>Email:</b> {p.email}</p><p><b>Role:</b> {p.role}</p><p><b>Verified:</b> {p.verified?'Yes':'No'}</p></div><div className="info-card"><h3>Profile</h3>{editing?<><Field label="Name" value={p.name} onChange={v=>setP({...p,name:v})}/><Field label="Phone" value={p.phone||''} onChange={v=>setP({...p,phone:v})}/><Field label="Photo URL" value={p.profilePhotoUrl||''} onChange={v=>setP({...p,profilePhotoUrl:v})}/><button className="btn btn-primary" onClick={save}>Save</button></>:<><p>{p.name}</p><p>{p.phone||'No phone added'}</p><button className="btn btn-secondary" onClick={()=>setEditing(true)}>Edit profile</button></>}</div></div><div className="panel" style={{marginTop:20}}><h3>Change password</h3><div className="info-grid" style={{gridTemplateColumns:'1fr 1fr'}}><Field label="Current password" type="password" value={pass.currentPassword} onChange={v=>setPass({...pass,currentPassword:v})}/><Field label="New password" type="password" value={pass.newPassword} onChange={v=>setPass({...pass,newPassword:v})}/></div><button className="btn btn-primary" style={{marginTop:14}} onClick={change}>Change password</button></div></div></div></main>}

function App(){const [page,setPage]=useState('home'),[data,setData]=useState(null),[session,setSession]=useState(null);useEffect(()=>{document.body.classList.add('page-ready')},[]);const go=(p,d)=>{setPage(p);setData(d)};return <Layout onHome={()=>go('home')}><>{page==='home'&&<Home go={go}/>} {page==='register'&&<Register go={go}/>} {page==='login'&&<Login go={go} setSession={setSession}/>} {page==='verify'&&<Verify email={data} go={go}/>} {page==='forgot'&&<Forgot go={go}/>} {page==='reset'&&<Reset email={data} go={go}/>} {page==='profile'&&<Profile session={session} clear={()=>{setSession(null);go('home')}}/>}</></Layout>}
createRoot(document.getElementById('root')).render(<App/>);
