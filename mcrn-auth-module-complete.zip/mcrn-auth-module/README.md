# Missing Child Rescue Network — Authentication Module

This starter implements the authentication module from scratch using:
- Spring Boot 3.5 / Java 21
- Spring Security + JWT
- MySQL + Spring Data JPA
- BCrypt password hashing
- Email OTP verification and password reset
- USER, POLICE and ADMIN roles
- React + Vite frontend
- The supplied MCRN CSS as the global stylesheet

## 1. Database
Make sure MySQL is running. The default configuration is:
- database: `mcrn_auth` (created automatically)
- username: `root`
- password: `root`

Change these using environment variables:
`DB_URL`, `DB_USERNAME`, `DB_PASSWORD`

## 2. Run backend
```bash
cd backend
./mvnw spring-boot:run
```
If there is no Maven wrapper:
```bash
mvn spring-boot:run
```

Backend: http://localhost:8080

## 3. Run frontend
```bash
cd frontend
npm install
npm run dev
```
Frontend: http://localhost:5173

## 4. Admin
An admin account is automatically seeded on first startup.
Defaults:
- username: `admin`
- password: `Admin@12345`

Change these with:
`ADMIN_USERNAME`, `ADMIN_PASSWORD`, `ADMIN_EMAIL`

There is deliberately no public admin registration endpoint.

## 5. Email OTP
If SMTP variables are not configured, OTPs are printed in the backend console for development:
`[MCRN DEV] OTP for ...`

For real email, configure:
`MAIL_HOST`, `MAIL_PORT`, `MAIL_USERNAME`, `MAIL_PASSWORD`

## 6. Main endpoints

POST `/api/auth/register/user`
POST `/api/auth/register/police`
POST `/api/auth/login`
POST `/api/auth/verify-email`
POST `/api/auth/forgot-password`
POST `/api/auth/reset-password`

GET `/api/user/profile`
PUT `/api/user/profile`
PUT `/api/user/change-password`

The role-specific application endpoints can later be added by your Police/Admin/Reporting teammates and protected with `hasRole` / `hasAnyRole`.

## Important
This is a college-project development baseline. Before real deployment, add server-side rate limiting, refresh-token/revocation strategy, stronger secret management, audit logging, HTTPS, production email configuration and automated tests.
